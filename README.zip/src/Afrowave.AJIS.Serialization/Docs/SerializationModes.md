﻿# Serialization Modes
