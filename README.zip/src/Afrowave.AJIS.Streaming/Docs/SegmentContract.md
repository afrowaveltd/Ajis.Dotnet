﻿# Segment Contract
