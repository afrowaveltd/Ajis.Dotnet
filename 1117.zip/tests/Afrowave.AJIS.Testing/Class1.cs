﻿namespace Afrowave.AJIS.Testing;

public class Class1
{

}
