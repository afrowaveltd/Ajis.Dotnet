﻿# Streaming Model
