﻿#nullable enable

using System.Runtime.CompilerServices;

namespace Afrowave.AJIS.Streaming.Walk;

/// <summary>
/// StreamWalk runner (API skeleton).
/// </summary>
public static class AjisStreamWalkRunner
{
   /// <summary>
   /// Runs the walker over an in-memory UTF-8 buffer.
   /// </summary>
   public static void Run(
      ReadOnlySpan<byte> inputUtf8,
      IAjisStreamWalkVisitor visitor,
      AjisStreamWalkOptions options,
      AjisStreamWalkRunnerOptions runnerOptions = default)
   {
      _ = visitor ?? throw new ArgumentNullException(nameof(visitor));
      _ = inputUtf8;
      _ = options;
      _ = runnerOptions;

      throw new NotImplementedException("StreamWalk runner not implemented yet. This is an API skeleton.");
   }

   /// <summary>
   /// Runs the walker over a stream and yields events (future).
   /// </summary>
   public static async IAsyncEnumerable<AjisStreamWalkEvent> WalkAsync(
      Stream input,
      AjisStreamWalkOptions options,
      [EnumeratorCancellation] CancellationToken ct = default)
   {
      _ = input ?? throw new ArgumentNullException(nameof(input));
      _ = options;
      _ = ct;
      await Task.CompletedTask;
      yield break;
   }
}