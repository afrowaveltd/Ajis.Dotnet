﻿# Afrowave.AJIS.Core

Core contracts, diagnostics, settings, localization, logging and event model for AJIS.

This project contains **no parsing or serialization logic**.
