﻿# Segment Contract
