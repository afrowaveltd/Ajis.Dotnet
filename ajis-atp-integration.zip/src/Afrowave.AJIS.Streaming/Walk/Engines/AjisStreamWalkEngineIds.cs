﻿#nullable enable

namespace Afrowave.AJIS.Streaming.Walk.Engines;

internal static class AjisStreamWalkEngineIds
{
   public const string M1_Span_Serial = "m1_span_serial";
   public const string LowMem_Span_Serial = "lowmem_span_serial";
}
