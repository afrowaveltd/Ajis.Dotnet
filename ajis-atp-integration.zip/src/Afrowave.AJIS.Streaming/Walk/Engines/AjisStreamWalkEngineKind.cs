﻿#nullable enable

namespace Afrowave.AJIS.Streaming.Walk.Engines;

public enum AjisStreamWalkEngineKind
{
   Serial = 0,
   Parallel = 1,
   FileMapped = 2
}
