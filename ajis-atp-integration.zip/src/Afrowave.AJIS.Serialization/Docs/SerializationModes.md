﻿# Serialization Modes

## Processing profiles

Serialization engines are selected using the processing profile hint:

* `Universal` -> balanced defaults
* `LowMemory` -> prefer low-memory engine
* `HighThroughput` -> prefer throughput engine
