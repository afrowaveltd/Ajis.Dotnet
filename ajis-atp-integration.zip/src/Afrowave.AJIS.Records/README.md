﻿# Afrowave.AJIS.Records

Record-based mapping helpers for AJIS.
