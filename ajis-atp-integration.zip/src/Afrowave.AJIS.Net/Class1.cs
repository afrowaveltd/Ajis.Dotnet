﻿namespace Afrowave.AJIS.Net;

public class Class1
{

}
