﻿# Afrowave.AJIS.Net

HTTP helpers and streaming integrations for AJIS.
