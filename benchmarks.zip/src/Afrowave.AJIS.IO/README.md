﻿# Afrowave.AJIS.IO

File-level operations for AJIS (search, replace, partial read/write).
