﻿namespace Afrowave.AJIS;

public class Class1
{

}
