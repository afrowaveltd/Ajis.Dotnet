﻿namespace Afrowave.AJIS.IO;

public class Class1
{

}
