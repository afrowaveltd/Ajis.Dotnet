﻿# Streaming Model
