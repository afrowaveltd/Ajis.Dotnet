﻿# Afrowave.AJIS.Streaming

Low-memory streaming parser producing AJIS segments.
