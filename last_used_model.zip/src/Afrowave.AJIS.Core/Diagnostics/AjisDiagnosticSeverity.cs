﻿#nullable enable

namespace Afrowave.AJIS.Core.Diagnostics;

public enum AjisDiagnosticSeverity
{
   Info = 0,
   Warning = 1,
   Error = 2,
}