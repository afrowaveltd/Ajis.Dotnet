﻿namespace Afrowave.AJIS.Records;

public class Class1
{

}
