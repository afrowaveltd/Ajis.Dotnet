﻿# Serialization Modes
