﻿# Afrowave.AJIS.Serialization

AJIS serialization APIs and segment-based serializers.
