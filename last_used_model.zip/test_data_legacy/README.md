# AJIS shared test data

Language-agnostic fixtures shared across all AJIS implementations.

Folders:
- common: examples and general valid docs
- lexer: tokenization fixtures (valid/invalid)
- parser: grammar/structure fixtures (valid/invalid)
