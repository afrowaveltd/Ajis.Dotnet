﻿#nullable enable

using Afrowave.AJIS.Core.Diagnostics;
using Afrowave.AJIS.Streaming.Walk;
using AjisDiag = Afrowave.AJIS.Core.Diagnostics.AjisDiagnostic;

namespace Afrowave.AJIS.Core.Tests.StreamWalk;

public sealed class LaxNotSupportedTests
{
   [Fact]
   public void Runner_LaxMode_IsRejected_WithModeNotSupported()
   {
      List<AjisDiag> diags = [];

      AjisStreamWalkRunnerOptions runnerOpt = new()
      {
         OnDiagnostic = d => diags.Add(d)
      };

      AjisStreamWalkOptions options = AjisStreamWalkOptions.DefaultForM1 with
      {
         Mode = AjisStreamWalkMode.Lax
      };

      CapturingVisitor visitor = new();

      AjisStreamWalkRunner.Run("{}"u8, options, visitor, runnerOpt);

      Assert.NotNull(visitor.Error);
      Assert.Equal(AjisDiagnosticKeys.ModeNotSupported, visitor.Error!.Code);

      Assert.Contains(diags, d => d.Code == AjisDiagnosticCode.ModeNotSupported);
   }

   private sealed class CapturingVisitor : IAjisStreamWalkVisitor
   {
      public AjisStreamWalkError? Error { get; private set; }

      public bool OnEvent(AjisStreamWalkEvent evt) => true;
      public void OnError(AjisStreamWalkError error) => Error = error;
      public void OnCompleted() { }
   }
}
