﻿#nullable enable

using Afrowave.AJIS.Streaming.Walk;
using Afrowave.AJIS.Testing.StreamWalk;

namespace Afrowave.AJIS.Core.Tests.StreamWalk;

public sealed class StreamWalkCaseSuiteTests
{
   [Fact]
   public void StreamWalk_CaseSuite_AllCasesPass()
   {
      string repoRoot = FindRepoRoot();
      string testDataRoot = Path.Combine(repoRoot, "test_data", "streamwalk");

      Assert.True(Directory.Exists(testDataRoot), $"Missing folder: {testDataRoot}");

      string[] caseFiles = Directory.GetFiles(testDataRoot, "*.case", SearchOption.AllDirectories);
      Assert.NotEmpty(caseFiles);

      List<string> failures = [];

      AjisStreamWalkRunnerOptions runnerOpt = new()
      {
         // Keep default diagnostics behavior; tests can still capture it per-case if needed.
      };

      foreach(string file in caseFiles.OrderBy(x => x, StringComparer.Ordinal))
      {
         try
         {
            AjisStreamWalkTestCase tc = AjisStreamWalkTestCaseFile.Load(file);
            AjisStreamWalkTestRunResult res = AjisStreamWalkTestRunner.Run(tc, runnerOpt);

            if(!res.Success)
               failures.Add($"{tc.CaseId} ({Path.GetRelativePath(repoRoot, file)}):\n- " +
                            string.Join("\n- ", res.Mismatches));
         }
         catch(Exception ex)
         {
            failures.Add($"{Path.GetRelativePath(repoRoot, file)}:\n- {ex.GetType().Name}: {ex.Message}");
         }
      }

      if(failures.Count > 0)
      {
         string msg =
            "StreamWalk .case suite failures:\n\n" +
            string.Join("\n\n", failures);

         Assert.Fail(msg);
      }
   }

   private static string FindRepoRoot()
   {
      // Walk up from test assembly base dir until we find the repository marker(s).
      string dir = AppContext.BaseDirectory;

      for(int i = 0; i < 12; i++)
      {
         if(File.Exists(Path.Combine(dir, "Ajis.Dotnet.slnx")) ||
            Directory.Exists(Path.Combine(dir, ".git")))
            return dir;

         DirectoryInfo? parent = Directory.GetParent(dir);
         if(parent is null) break;
         dir = parent.FullName;
      }

      throw new DirectoryNotFoundException("Could not locate repository root (Ajis.Dotnet.slnx or .git not found).");
   }
}
