﻿#nullable enable

using Afrowave.AJIS.Testing.StreamWalk;

namespace Afrowave.AJIS.Core.Tests.StreamWalk;

public sealed class RenderSliceTests
{
   [Fact]
   public void RenderSlice_EscapesCommonCharacters_Deterministically()
   {
      ReadOnlySpan<byte> bytes = "a\\b\n\t\r\""u8;

      string rendered = AjisStreamWalkTestCaseFile.RenderSlice(bytes);

      Assert.Equal("b\"a\\\\b\\n\\t\\r\\\"\"", rendered);
   }

   [Fact]
   public void RenderSlice_UsesHexEscape_ForControlBytes()
   {
      byte[] bytes = [0x01, 0x02, (byte)'A'];

      string rendered = AjisStreamWalkTestCaseFile.RenderSlice(bytes);

      Assert.Equal("b\"\\x01\\x02A\"", rendered);
   }
}
