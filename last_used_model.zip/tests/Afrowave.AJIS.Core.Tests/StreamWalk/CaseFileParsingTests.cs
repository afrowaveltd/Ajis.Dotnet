﻿#nullable enable

using Afrowave.AJIS.Testing.StreamWalk;
using System.Text;

namespace Afrowave.AJIS.Core.Tests.StreamWalk;

public sealed class CaseFileParsingTests
{
   [Fact]
   public void Load_CanonicalSuccess_ParsesOptionsInputAndTrace()
   {
      string src = """
      # OPTIONS
      MODE: AJIS
      COMMENTS: OFF

      # INPUT
      {"a":1}

      # EXPECTED
      OBJ_BEGIN b"{"
      NAME b"\"a\""
      NUM b"1"
      OBJ_END b"}"
      """;

      AjisStreamWalkTestCase tc = LoadFromString(src);

      Assert.Equal(AjisStreamWalkTestMode.AJIS, tc.Options.Mode);
      Assert.False(tc.Options.Comments);

      AjisStreamWalkTestExpected.Success ok = Assert.IsType<AjisStreamWalkTestExpected.Success>(tc.Expected);
      Assert.Equal(4, ok.Trace.Count);
      Assert.Equal("OBJ_BEGIN", ok.Trace[0].Kind);
      Assert.Equal("b\"{\"", ok.Trace[0].Slice);
   }

   [Fact]
   public void Load_CanonicalFailure_ParsesErrorFields()
   {
      string src = """
      # INPUT
      { "a":

      # EXPECTED
      ERROR unexpected_eof offset=7 line=1 col=7
      """;

      AjisStreamWalkTestCase tc = LoadFromString(src);

      AjisStreamWalkTestExpected.Failure fail = Assert.IsType<AjisStreamWalkTestExpected.Failure>(tc.Expected);
      Assert.Equal("unexpected_eof", fail.Code);
      Assert.Equal(7, fail.Offset);
      Assert.Equal(1, fail.Line);
      Assert.Equal(7, fail.Col);
   }

   [Fact]
   public void Load_LegacyFormats_AreAccepted()
   {
      string src = """
      # OPTIONS
      MODE=JSON
      COMMENTS=OFF

      # INPUT
      {"a":1}

      # EXPECTED
      OK
      TRACE:
      OBJ_BEGIN b"{"
      OBJ_END b"}"
      """;

      AjisStreamWalkTestCase tc = LoadFromString(src);

      Assert.Equal(AjisStreamWalkTestMode.JSON, tc.Options.Mode);
      Assert.False(tc.Options.Comments);

      AjisStreamWalkTestExpected.Success ok = Assert.IsType<AjisStreamWalkTestExpected.Success>(tc.Expected);
      Assert.Equal(2, ok.Trace.Count);
      Assert.Equal("OBJ_BEGIN", ok.Trace[0].Kind);
      Assert.Equal("b\"{\"", ok.Trace[0].Slice);
   }

   private static AjisStreamWalkTestCase LoadFromString(string src)
   {
      string path = Path.Combine(Path.GetTempPath(), $"ajis_case_{Guid.NewGuid():N}.case");
      File.WriteAllText(path, src.Replace("\r\n", "\n"), Encoding.UTF8);
      try
      {
         return AjisStreamWalkTestCaseFile.Load(path);
      }
      finally
      {
         try { File.Delete(path); } catch { /* ignore */ }
      }
   }
}
